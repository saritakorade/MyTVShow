<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Anime Template">
    <meta name="keywords" content="Anime, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MyTVShow</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@300;400;500;600;700;800;900&display=swap"
    rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/plyr.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>

<?php 
//phpinfo();
									
		$url = 'http://api.tvmaze.com/search/shows?q='.$_GET['search_str'];
		$cURL = curl_init();
		curl_setopt($cURL, CURLOPT_URL, $url);
		curl_setopt($cURL, CURLOPT_HTTPGET, true);
		curl_setopt($cURL, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Accept: application/json'
		));
		curl_setopt($cURL, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($cURL);
		curl_close($cURL);


		$data = json_decode($result, true);
		//print_r($data);

?>

    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Header Section Begin -->
    <header class="header">
        <div class="container">
            <div class="row">
                <div class="col-lg-2">
                    <div class="header__logo">
                        <a href="./index.php">
                            <img src="img/logo.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="header__nav">
                        <nav class="header__menu mobile-menu">
                            <ul>
                                <li><a href="./index.php">Dashboard</a></li>                                
								<li><a href="./categories.php?gen=Drama">Drama</a></li>
                                <li><a href="./categories.php?gen=Comedy">Comedy</a>
								<li><a href="./categories.php?gen=Food">Food</a></li>
								
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="header__right">
                        <a href="#" class="search-switch"><span class="icon_search"></span></a>
                       <!-- <a href="./login.html"><span class="icon_profile"></span></a>-->
                    </div>
                </div>
            </div>
            <div id="mobile-menu-wrap"></div>
        </div>
    </header>
    <!-- Header End -->
    
   

    <!-- Product Section Begin -->
    <section class="product spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    
                    
                    <div class="recent__product">
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-8">
                                <div class="section-title">
                                    <h4>Search For-- <small><?php echo $_GET['search_str']; ?></small></h4>
                                </div>
                            </div>
                            
                        </div>
						
                        <div class="row">
						
						<?php	
											
						if(empty($data))
						{
							echo "<h3 class='norecords'>No Records Found<h5>";
						}
						else{
						for($gen=0;$gen<count($data);$gen++){
						
							
								
								//$cat=implode(',',$data[$gen]['genres']);
								
										
								
								if($data[$gen]['show']['image'] !='')
								{
									//echo $data[$gen]['show']['id'];
									//var_dump($data[$gen]);
									
										
											
										?>
										
										<div class="col-lg-4 col-md-6 col-sm-6">
										
											<a href="showDetails.php?id=<?php echo $data[$gen]['show']['id'];?>">
												<div class="product__item">

													<div class="product__item__pic set-bg" data-setbg=<?php echo $data[$gen]['show']['image']['medium'];?>>
														
													</div>
													<div class="product__item__text">
														<h5><a href="#"><?php echo $data[$gen]['show']['name']; ?></a></h5>
													</div>
												</div>
										</a>
										</div>
									<?php   
										
									
								}
							
							
							
						}
						}
						?>
						
                           
                        </div>
                    </div>
                    
					
				</div>
      
</div>
</div>
</section>
<!-- Product Section End -->

<!-- Footer Section Begin -->
<footer class="footer">
    <div class="page-up">
        <a href="#" id="scrollToTopButton"><span class="arrow_carrot-up"></span></a>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="footer__logo">
                    <a href="./index.php"><img src="img/logo.png" alt=""></a>
                </div>
            </div>
            
            <div class="col-lg-4">
                <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved </p>

              </div>
          </div>
      </div>
  </footer>
  <!-- Footer Section End -->

  <!-- Search model Begin -->
  <div class="search-model">
    <div class="h-100 d-flex align-items-center justify-content-center">
        <div class="search-close-switch"><i class="icon_close"></i></div>
        <form class="search-model-form" action="search.php">
            <input type="text" id="searchShow" name="search_str" placeholder="Search here.....">
        </form>
    </div>
	
    
</div>
<!-- Search model end -->

<!-- Js Plugins -->
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/player.js"></script>
<script src="js/jquery.nice-select.min.js"></script>
<script src="js/mixitup.min.js"></script>
<script src="js/jquery.slicknav.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/main.js"></script>


</body>

</html>