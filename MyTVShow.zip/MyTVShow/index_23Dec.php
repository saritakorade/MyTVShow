<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Anime Template">
    <meta name="keywords" content="Anime, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MyTVShow</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@300;400;500;600;700;800;900&display=swap"
    rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/plyr.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>

<?php 
//phpinfo();
									
		$url = 'http://api.tvmaze.com/shows?page=1';
		$cURL = curl_init();
		curl_setopt($cURL, CURLOPT_URL, $url);
		curl_setopt($cURL, CURLOPT_HTTPGET, true);
		curl_setopt($cURL, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Accept: application/json'
		));
		curl_setopt($cURL, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($cURL);
		curl_close($cURL);


		$data = json_decode($result, true);
		

?>

    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Header Section Begin -->
    <header class="header">
        <div class="container">
            <div class="row">
                <div class="col-lg-2">
                    <div class="header__logo">
                        <a href="./index.php">
                            <img src="img/logo.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="header__nav">
                        <nav class="header__menu mobile-menu">
                            <ul>
                                <li class="active"><a href="./index.php">Dashboard</a></li>                                
								<li><a href="./categories.php?gen=Drama">Drama</a></li>
                                <li><a href="./categories.php?gen=Comedy">Comedy</a>
								<li><a href="./categories.php?gen=Food">Food</a></li>
								
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="header__right">
                        <a href="#" class="search-switch"><span class="icon_search"></span></a>
                       <!-- <a href="./login.html"><span class="icon_profile"></span></a>-->
                    </div>
                </div>
            </div>
            <div id="mobile-menu-wrap"></div>
        </div>
    </header>
    <!-- Header End -->

    <!-- Hero Section Begin -->
    <section class="hero">
        <div class="container">
            <div class="hero__slider owl-carousel">
                <div class="hero__items set-bg" data-setbg="img/hero/hero-1.png">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="hero__text">
                                <!--<div class="label">Adventure</div>-->
                                <h2>Every superhero has a beginning</h2>
                                <p>Adventure...</p>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hero__items set-bg" data-setbg="img/hero/hero-2.png">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="hero__text">
                                <!--<div class="label">Adventure</div>-->
                                <h2>A lot can happen in a day</h2>
                                <p>travel across the world...</p>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hero__items set-bg" data-setbg="img/hero/hero-3.png">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="hero__text">
                                <!--<div class="label">Adventure</div>-->
                                <h2>To catch a criminal, you have to think like one</h2>
                                <p>Suspence...</p>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- Product Section Begin -->
    <section class="product spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    
                    <div class="popular__product">
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-8">
                                <div class="section-title">
                                    <h4>Popular Shows</h4>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <div class="btn__all">
                                    <a href="./categories.php?gen=All" class="primary-btn">View All <span class="arrow_right"></span></a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
						
						<?php
						 
							for($gen=0;$gen<7;$gen++){
								if($data[$gen]['rating']['average'] !=''){
								//echo $data[$gen]['name']."---".$data[$gen]['rating']['average']."<br>";
								$noarray = $data[$gen]['rating']['average'].",";
							   //$res = natsort($noarray);

								//echo "<pre>";
								//print_r($noarray);
								$numbers = array($noarray);
								//var_dump($numbers);

								//print_r(rsort($numbers));

								$arrlength = count($numbers);
								for($x = 0; $x < $arrlength; $x++) {
								  //echo $numbers[$x];
								  //echo "<br>";
								}
								?>
								<div class="col-lg-4 col-md-6 col-sm-6">
											<a href="showDetails.php?id=<?php echo $data[$gen]['id'];?>">
												<div class="product__item">
													<div class="product__item__pic set-bg" data-setbg=<?php echo $data[$gen]['image']['medium'];?>>
														
													</div>
													<div class="product__item__text">
														<h5><a href="#"><?php echo $data[$gen]['name']; ?></a></h5>
													</div>
												</div>
											</a>
										</div>
								<?php
							}
						?>
						
						<?php
						}
						
						?>
						
                           
                        </div>
                    </div>
                    <div class="recent__product">
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-8">
                                <div class="section-title">
                                    <h4>Drama</h4>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <div class="btn__all">
                                    <a href="./categories.php?gen=Drama" class="primary-btn">View All <span class="arrow_right"></span></a>
                                </div>
                            </div>
                        </div>
						
                        <div class="row">
						
						<?php					
						
						for($gen=0;$gen<count($data);$gen++){
						
							if (count($data[$gen]['genres']) > 0){
								
								$cat=implode(',',$data[$gen]['genres']);
							
								
								if($cat=='Drama')
								{ 
									//echo $data[$gen]['id'];
									
										?>
										
										<div class="col-lg-4 col-md-6 col-sm-6">
										
											<a href="showDetails.php?id=<?php echo $data[$gen]['id'];?>">
												<div class="product__item">

													<div class="product__item__pic set-bg" data-setbg=<?php echo $data[$gen]['image']['medium'];?>>
														
													</div>
													<div class="product__item__text">
														<h5><a href="#"><?php echo $data[$gen]['name']; ?></a></h5>
													</div>
												</div>
										</a>
										</div>
									<?php 
								}
									
								
							}
							
							
						}
						
						?>
						
                           
                        </div>
                    </div>
                    <div class="trending__product">
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-8">
                                <div class="section-title">
                                    <h4>Comedy</h4>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <div class="btn__all">
                                    <a href="./categories.php?gen=Comedy" class="primary-btn">View All <span class="arrow_right"></span></a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <?php					
						
						for($gen=0;$gen<count($data);$gen++){
							//if(@$data[$gen]['genres'][0]!=''){echo @$data[$gen]['genres'][0];}
							//echo count($data);
							if (count($data[$gen]['genres']) > 0){
								//echo "--".implode(',',$data[$gen]['genres']);
								$cat=implode(',',$data[$gen]['genres']);
								
								if($cat=='Comedy')
								{ 
									//echo count($cat)."<br>";
									
									
										
									?>
									<?php  ?>
									<div class="col-lg-4 col-md-6 col-sm-6">
										<a href="showDetails.php?id=<?php echo $data[$gen]['id'];?>">
											<div class="product__item">
												<div class="product__item__pic set-bg" data-setbg=<?php echo $data[$gen]['image']['medium'];?>>
													
												</div>
												<div class="product__item__text">
													<h5><a href="#"><?php echo $data[$gen]['name']; ?></a></h5>
												</div>
											</div>
										</a>
									</div>
								<?php 
									
								}	
							}			
							
						}
						?>
                        </div>
                    </div>
					<div class="trending__product">
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-8">
                                <div class="section-title">
                                    <h4>Foods</h4>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <div class="btn__all">
                                    <a href="./categories.php?gen=Food" class="primary-btn">View All <span class="arrow_right"></span></a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <?php					
						
								for($gen=0;$gen<count($data);$gen++){
									//if(@$data[$gen]['genres'][0]!=''){echo @$data[$gen]['genres'][0];}
									//echo count($data);
									if (count($data[$gen]['genres']) > 0){
										//echo "--".implode(',',$data[$gen]['genres']);
										$cat=implode(',',$data[$gen]['genres']);
										//echo $cat."<br>";
										if($cat=='Food')
										{ ?>
											<div class="col-lg-4 col-md-6 col-sm-6">
												<a href="showDetails.php?id=<?php echo $data[$gen]['id'];?>">
													<div class="product__item">
														<div class="product__item__pic set-bg" data-setbg=<?php echo $data[$gen]['image']['medium'];?>>
															
														</div>
														<div class="product__item__text">
															<h5><a href="#"><?php echo $data[$gen]['name']; ?></a></h5>
														</div>
													</div>
												</a>
											</div>
										<?php }	
											
										
									}
									
									
								}
						?>
                        </div>
                    </div>
				</div>
      
</div>
</div>
</section>
<!-- Product Section End -->

<!-- Footer Section Begin -->
<footer class="footer">
    <div class="page-up">
        <a href="#" id="scrollToTopButton"><span class="arrow_carrot-up"></span></a>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="footer__logo">
                    <a href="./index.php"><img src="img/logo.png" alt=""></a>
                </div>
            </div>
            
            <div class="col-lg-4">
                <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved </p>

              </div>
          </div>
      </div>
  </footer>
  <!-- Footer Section End -->

  <!-- Search model Begin -->
  <div class="search-model">
    <div class="h-100 d-flex align-items-center justify-content-center">
        <div class="search-close-switch"><i class="icon_close"></i></div>
        <form class="search-model-form">
            <input type="text" id="searchShow" placeholder="Search here.....">
        </form>
    </div>
	
    
</div>
<!-- Search model end -->

<!-- Js Plugins -->
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/player.js"></script>
<script src="js/jquery.nice-select.min.js"></script>
<script src="js/mixitup.min.js"></script>
<script src="js/jquery.slicknav.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/main.js"></script>


</body>

</html>